package dgtic.core.repository.repositorio;

import dgtic.core.model.entidades.Proyecto;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProyectoRepository extends JpaRepository<Proyecto,Integer>{
}
