package dgtic.core.repository.repositorio;

import dgtic.core.model.entidades.ComentarioTarea;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ComentarioTareaRepository extends JpaRepository<ComentarioTarea,Integer> {
}
