package dgtic.core.controller.usuario;

import dgtic.core.model.entidades.Rol;
import dgtic.core.model.entidades.Usuario;
import dgtic.core.service.rol.RolService;
import dgtic.core.service.usuario.UsuarioService;
import dgtic.core.util.RenderPagina;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.validation.Valid;
import java.util.List;

@Controller
@RequestMapping("usuario")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private RolService rolService;

    // Mostrar el formulario para dar de alta un usuario
    @GetMapping("/alta-usuario")
    public String altaUsuario(Model model) {
        Usuario usuario = new Usuario();
        List<Rol> roles = rolService.roles();  // Cargar los roles disponibles

        model.addAttribute("usuario", usuario);
        model.addAttribute("selectRol", roles);  // Pasar la lista de roles al modelo
        model.addAttribute("contenido", "Alta de un Usuario");

        return "usuario/alta-usuario";  // Nombre de la plantilla HTML
    }

    // Procesar el formulario para guardar el nuevo usuario
    @PostMapping("/salvar-usuario")
    public String salvarUsuario(@Valid @ModelAttribute("usuario") Usuario usuario,
                                BindingResult result,
                                Model model,
                                RedirectAttributes flash) {
        // Verificar si hay errores en el formulario
        if (result.hasErrors()) {
            List<Rol> roles = rolService.roles();  // Recargar la lista de roles en caso de error
            model.addAttribute("selectRol", roles);
            model.addAttribute("contenido", "Error en el formulario de usuario");

            return "usuario/alta-usuario";
        }

        usuarioService.guardar(usuario);  // Guardar el usuario en la base de datos
        flash.addFlashAttribute("success", "Usuario guardado exitosamente");

        return "redirect:/usuario/lista-usuario";  // Redirigir a la lista de usuarios
    }

    @GetMapping("/lista-usuario")
    public String listaUsuarios(@RequestParam(name = "page", defaultValue = "0") int page, Model model) {
        Pageable pageable = PageRequest.of(page, 3); // Configura el tamaño de página, en este caso, 10 elementos por página
        Page<Usuario> usuario = usuarioService.buscarUsuario(pageable); //
        RenderPagina<Usuario> renderPagina = new RenderPagina<>("lista-usuario", usuario);

        model.addAttribute("page", renderPagina);
        model.addAttribute("usuarios", usuario);
        model.addAttribute("contenido", "Lista de Usuarios");

        return "usuario/lista-usuario"; // Nombre de la plantilla para listar usuarios
    }
}