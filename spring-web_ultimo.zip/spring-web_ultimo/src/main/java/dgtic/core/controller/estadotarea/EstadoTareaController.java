package dgtic.core.controller.estadotarea;

import dgtic.core.model.entidades.EstadoTarea;
import dgtic.core.model.entidades.Rol;
import dgtic.core.service.estadotarea.EstadoTareaService;
import dgtic.core.util.RenderPagina;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/estadotarea")
public class EstadoTareaController {

    @Autowired
    EstadoTareaService estadoTareaService;

    @GetMapping("/alta-estado-tarea")
    public String altaEstadoTarea(Model model) {
        EstadoTarea estadoTarea = new EstadoTarea();
        model.addAttribute("contenido", "Alta de un Estado de Tarea");
        model.addAttribute("estadoTarea", estadoTarea);
        return "estadotarea/alta-estado-tarea";
    }

    @PostMapping("/salvar-estado-tarea")
    public String salvarEstado(@Valid @ModelAttribute("estadoTarea") EstadoTarea estadoTarea,
                               BindingResult result, Model model, RedirectAttributes flash) {
        if (result.hasErrors()) {
            model.addAttribute("contenido", "Error en el nombre del estado. No debe estar vacío.");
            return "estadotarea/alta-estado-tarea";
        }
        estadoTareaService.guardar(estadoTarea);
        flash.addFlashAttribute("success", "El estado se guardó correctamente.");
        return "redirect:/estadotarea/lista-estado-tarea";
    }

    @GetMapping("/lista-estado-tarea")
    public String listaEstados(@RequestParam(name = "page", defaultValue = "0") int page, Model model) {
        Pageable pageable = PageRequest.of(page, 5);
        Page<EstadoTarea> estados = estadoTareaService.buscarEstadoTareas(pageable);
        RenderPagina<EstadoTarea> renderPagina = new RenderPagina<>("lista-estado-tarea", estados);
        model.addAttribute("estados", estados);
        model.addAttribute("page", renderPagina);
        model.addAttribute("contenido", "Lista de Estados de Tareas");
        return "estadotarea/lista-estado-tarea";
    }

    @GetMapping("/eliminar-estado-tarea/{id}")
    public String eliminarEstado(@PathVariable("id") Integer id, RedirectAttributes flash) {
        estadoTareaService.borrar(id);
        flash.addFlashAttribute("success", "El estado fue eliminado correctamente.");
        return "redirect:/estadotarea/lista-estado-tarea";
    }

    @GetMapping("/modificar-estado-tarea/{id}")
    public String modificarEstado(@PathVariable("id") Integer id, Model model) {
        EstadoTarea estadoTarea = estadoTareaService.buscarEstadoTareaId(id);
        model.addAttribute("estadoTarea", estadoTarea);
        model.addAttribute("contenido", "Modificar Estado de Tarea");
        return "estadotarea/alta-estado-tarea";
    }
}