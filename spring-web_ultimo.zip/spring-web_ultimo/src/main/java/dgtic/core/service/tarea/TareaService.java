package dgtic.core.service.tarea;

import dgtic.core.model.entidades.Tarea;
import dgtic.core.model.entidades.Usuario;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface TareaService {
    Page<Tarea> buscarTarea(Pageable pageable);
    List<Tarea> buscarTarea();
    void guardar(Tarea tarea);
    void borrar(Integer id);
    Tarea buscartTareaId(Integer id);
        List<Tarea> buscarTarea(Integer id);
}
