package dgtic.core.service.proyecto;

public interface ProyectoService {
}
