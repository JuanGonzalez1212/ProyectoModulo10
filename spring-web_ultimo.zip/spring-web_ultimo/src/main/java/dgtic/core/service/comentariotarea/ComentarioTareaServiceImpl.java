package dgtic.core.service.comentariotarea;

public class ComentarioTareaServiceImpl {
}
