package dgtic.core.service.estadotarea;

import dgtic.core.model.entidades.EstadoTarea;
import dgtic.core.model.entidades.Rol;
import dgtic.core.repository.repositorio.EstadoTareaRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class EstadoTareaServiceImpl implements EstadoTareaService {

    @Autowired
    EstadoTareaRepository estadoTareaRepository;

    @Override
    public Page<EstadoTarea> buscarEstadoTareas(Pageable pageable) {
        return estadoTareaRepository.findAll(pageable);
    }

    @Override
    public void guardar(EstadoTarea estadoTarea) {
        estadoTareaRepository.save(estadoTarea);
    }

    @Override
    public void borrar(Integer id) {
        estadoTareaRepository.deleteById(id);
    }

    @Override
    public EstadoTarea buscarEstadoTareaId(Integer id) {
        Optional<EstadoTarea> et =estadoTareaRepository.findById(id);
        return et.orElse(null);
    }

    @Override
    public List<EstadoTarea> estados() {
        return estadoTareaRepository.findAll();
    }
}
