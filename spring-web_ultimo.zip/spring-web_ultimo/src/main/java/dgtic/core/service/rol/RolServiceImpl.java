package dgtic.core.service.rol;

import dgtic.core.model.entidades.Rol;
import dgtic.core.repository.repositorio.RolRepository;
import org.aspectj.lang.annotation.DeclareAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class RolServiceImpl implements RolService {

    @Autowired
    RolRepository rolRepository;

    @Override
    @Transactional(readOnly = true)
    public List<Rol> buscarRol() {
        return rolRepository.findAll();  // Devuelve una lista completa de roles
    }

    @Override
    @Transactional
    public void guardar(Rol rol) {
        rolRepository.save(rol);
    }

    @Override
    @Transactional
    public void borrar(Integer id) {
        rolRepository.deleteById(id);
    }

    @Override
    @Transactional
    public Rol buscarRolId(Integer id) {
        Optional<Rol> op=rolRepository.findById(id);
        return op.orElse(null);
    }

    @Override
    @Transactional
    public List<Rol> roles() {
        return rolRepository.findAll();
    }
}
