package dgtic.core.service.miembroproyecto;

public interface MiembroProyectoService {
}
