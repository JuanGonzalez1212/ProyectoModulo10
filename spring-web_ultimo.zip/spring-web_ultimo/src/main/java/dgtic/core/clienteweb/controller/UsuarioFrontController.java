package dgtic.core.clienteweb.controller;

public class UsuarioFrontController {
}
