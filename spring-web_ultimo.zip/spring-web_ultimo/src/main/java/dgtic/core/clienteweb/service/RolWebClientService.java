package dgtic.core.clienteweb.service;

import dgtic.core.model.entidades.Rol;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class RolWebClientService {
    @Autowired
    private WebClient webClient;

    public List<Rol> getAll() {
        Mono<List<Rol>> rolesMono = webClient.get()
                .uri("/api/rol")  // No se necesita ningún parámetro de paginación
                .retrieve()
                .bodyToFlux(Rol.class)  // Se deserializa la respuesta como un flujo de roles
                .collectList();         // Recoge todos los elementos en una lista

        List<Rol> roles = rolesMono.block();  // Espera a que se obtenga la lista
        return roles;
    }


    public Rol getRolById(Integer id) {
        Mono<Rol> rolDtoMono = webClient.get()
                .uri("/api/rol/{id}", id)
                .retrieve()
                .bodyToMono(Rol.class);
        return rolDtoMono.block();
    }

    public Rol createRol(Rol rolDto) {
        return webClient.post()
                .uri("/api/rol")
                .bodyValue(rolDto)
                .retrieve()
                .bodyToMono(Rol.class)
                .block();
    }

    public Rol updateRol(Integer id, Rol rolDto) {
        return webClient.put()
                .uri("/api/rol/{id}", id)
                .bodyValue(rolDto)
                .retrieve()
                .bodyToMono(Rol.class)
                .block();
    }

    public String deleteRol(Integer id) {
        return webClient.delete()
                .uri("/api/rol/{id}", id)
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }
}
