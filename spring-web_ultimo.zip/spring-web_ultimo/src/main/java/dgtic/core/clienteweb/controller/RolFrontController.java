package dgtic.core.clienteweb.controller;

import dgtic.core.clienteweb.service.RolWebClientService;
import dgtic.core.converter.MayusculasConverter;
import dgtic.core.model.entidades.Rol;
import dgtic.core.service.rol.RolService;
import dgtic.core.util.RenderPagina;
import dgtic.core.validation.TipoValidacion;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
//endpoint localhost:8080/tipo/alta-tipo
@RequestMapping(value = "rol")
public class RolFrontController {

    @Autowired
    TipoValidacion tipoValidacion;
    @Autowired
    RolWebClientService rolService;

    @GetMapping("alta-rol")
    public String altaRol(Model model) {
        Rol rol = new Rol();
        model.addAttribute("contenido", "Alta de un Rol");
        //model.addAttribute("success","nombre"); no utilizar no funciona no lo gestionas tu
        model.addAttribute("rol", rol);

        return "rol/alta-rol";
    }


    @PostMapping("salvar-rol")
    public String salvarRol(@Valid @ModelAttribute("rol") Rol rol, BindingResult result,
                            Model model, RedirectAttributes flash) {
        if (result.hasErrors()) {
            model.addAttribute("contenido", "Error en el nombre, no debe de ser vacio");
            return "rol/alta-rol";
        }
        rolService.createRol(rol);
        //model.addAttribute("contenido","Alta de Tipo");
        flash.addFlashAttribute("success", "Se almaceno con exito");
        //model.addAttribute("tipo",tipo);

        //return "tipo/alta-tipo";
        return "redirect:/rol/lista-rol";
    }

    @GetMapping("lista-rol")
    public String listaRol(Model model) {
        List<Rol> rol = rolService.getAll();  // Ahora, getAll devuelve una lista sin paginación
        model.addAttribute("rol", rol);  // Agregar la lista de roles al modelo
        model.addAttribute("contenido", "Lista de Roles Disponibles para Usuarios");
        return "rol/lista-rol";  // Retorna la vista lista-rol
    }

    @GetMapping("eliminar-rol/{id}")
    public String eliminar(@PathVariable("id") Integer id, RedirectAttributes flash) {
        rolService.deleteRol(id);
        flash.addFlashAttribute("success", "Se borro con exito el Rol");
        return "redirect:/rol/lista-rol";
    }

    @GetMapping("modificar-rol/{id}")
    public String saltoModificar(@PathVariable("id") Integer id, Model model) {
        Rol rol = rolService.getRolById(id);
        model.addAttribute("rol", rol);
        model.addAttribute("contenido", "Modificar el Rol de Usuario");
        return "rol/alta-rol";

    }

    @InitBinder("rol")
    public void nombreRol(WebDataBinder binder) {
        //binder.addValidators(tipoValidacion);
        binder.registerCustomEditor(String.class,
                "nombre", new MayusculasConverter());
    }
}