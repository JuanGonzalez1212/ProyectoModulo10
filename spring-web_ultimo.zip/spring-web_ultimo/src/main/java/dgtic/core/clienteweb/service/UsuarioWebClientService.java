package dgtic.core.clienteweb.service;

public class UsuarioWebClientService {
}
