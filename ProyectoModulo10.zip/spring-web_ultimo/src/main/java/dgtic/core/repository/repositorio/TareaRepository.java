package dgtic.core.repository.repositorio;

import dgtic.core.model.entidades.Tarea;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TareaRepository extends JpaRepository<Tarea,Integer> {
}
