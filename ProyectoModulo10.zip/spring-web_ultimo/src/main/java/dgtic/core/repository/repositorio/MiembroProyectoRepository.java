package dgtic.core.repository.repositorio;

import dgtic.core.model.entidades.MiembroProyecto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.orm.jpa.JpaTransactionManager;

public interface MiembroProyectoRepository extends JpaRepository<MiembroProyecto,Integer> {
}
