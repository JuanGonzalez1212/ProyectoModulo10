package dgtic.core.repository.repositorio;

import dgtic.core.model.entidades.Rol;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RolRepository extends JpaRepository<Rol,Integer> {
}
