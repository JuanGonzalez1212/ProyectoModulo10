package dgtic.core.repository.repositorio;

import dgtic.core.model.entidades.EstadoTarea;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

public interface EstadoTareaRepository extends JpaRepository<EstadoTarea,Integer> {
}
