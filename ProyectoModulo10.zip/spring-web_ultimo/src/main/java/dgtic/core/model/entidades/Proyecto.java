package dgtic.core.model.entidades;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;
import java.util.Set;

@Entity(name = "proyecto")
@Table(name = "Proyecto")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Proyecto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_proyecto")
    private Integer idProyecto;

    @Column(name = "nombre", nullable = false, length = 100)
    private String nombre;

    @Column(name = "descripcion", length = 500)
    private String descripcion;

    @Column(name = "fecha_inicio")
    private java.sql.Date fechaInicio;

    @Column(name = "fecha_fin")
    private java.sql.Date fechaFin;

    @ManyToOne
    @JoinColumn(name = "id_jefe_departamento", referencedColumnName = "id_usuario")
    private Usuario jefeDepartamento;

    @OneToMany(mappedBy = "proyecto")
    private Set<Tarea> tareas;

    @OneToMany(mappedBy = "proyecto")
    private Set<MiembroProyecto> miembroProyecto;

}