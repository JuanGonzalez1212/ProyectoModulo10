package dgtic.core.model.entidades;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity(name = "comentariotarea")
@Table(name = "comentariotarea")
@Data
@AllArgsConstructor
@Builder
public class ComentarioTarea {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_comentario")
    private Integer idComentario;

    @ManyToOne
    @JoinColumn(name = "id_tarea", referencedColumnName = "id_tarea")
    private Tarea tarea;

    @ManyToOne
    @JoinColumn(name = "id_usuario", referencedColumnName = "id_usuario")
    private Usuario usuario;

    @Column(name = "comentario", length = 500)
    private String comentario;

    @Column(name = "fecha")
    private LocalDateTime fecha;

    public ComentarioTarea() {
    }

    public ComentarioTarea(Integer idComentario, Tarea tarea, Usuario usuario) {
        this.idComentario = idComentario;
        this.tarea = tarea;
        this.usuario = usuario;
    }
}