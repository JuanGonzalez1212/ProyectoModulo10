package dgtic.core.model.entidades;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Entity (name = "usuario")
@Table(name = "Usuario")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_usuario")
    private Integer idUsuario;

    @Column(name = "nombre", nullable = false, length = 100)
    private String nombre;

    @Column(name = "apellido_paterno", nullable = false, length = 50)
    private String apellidoPaterno;

    @Column(name = "apellido_materno", length = 50)
    private String apellidoMaterno;

    @Column(name = "email", nullable = false, length = 150, unique = true)
    private String email;

    @Column(name = "contraseña", nullable = false, length = 50)
    private String password;

    @ManyToOne
    @JoinColumn(name = "id_rol", referencedColumnName = "id_rol")
    private Rol rol;

    @OneToMany(mappedBy = "jefeDepartamento")
    private Set<Proyecto> proyectosComoJefe;

    @OneToMany(mappedBy = "usuarioAsignado")
    private Set<Tarea> tareasAsignadas;

    @OneToMany(mappedBy = "usuario")
    private Set<MiembroProyecto> miembroProyectos;

    @OneToMany(mappedBy = "usuario")
    private Set<ComentarioTarea> comentarios;

    public void setId(Integer id) {
    }
}