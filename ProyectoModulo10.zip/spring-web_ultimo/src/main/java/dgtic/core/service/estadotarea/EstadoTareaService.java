package dgtic.core.service.estadotarea;

import dgtic.core.model.entidades.EstadoTarea;
import dgtic.core.model.entidades.Rol;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface EstadoTareaService {
    Page<EstadoTarea> buscarEstadoTareas(Pageable pageable);
    void guardar(EstadoTarea estadoTarea);
    void borrar(Integer id);
    EstadoTarea buscarEstadoTareaId(Integer id);
    List<EstadoTarea> estados();

}
