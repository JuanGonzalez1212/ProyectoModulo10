package dgtic.core.service.proyecto;

public class ProyectoServiceImpl {
}
