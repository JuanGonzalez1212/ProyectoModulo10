package dgtic.core.service.usuario;

import dgtic.core.model.entidades.Usuario;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface UsuarioService {
    Page<Usuario> buscarUsuario(Pageable pageable);
    List<Usuario> usuarios();
    void guardar(Usuario usuario);
    void borrar(Integer id);
    Usuario busacarUsuarioId(Integer id);
    List<Usuario> buscarUsuario(Integer id);
}
