package dgtic.core.service.miembroproyecto;

public class MiembroProyectoServiceImpl {
}
