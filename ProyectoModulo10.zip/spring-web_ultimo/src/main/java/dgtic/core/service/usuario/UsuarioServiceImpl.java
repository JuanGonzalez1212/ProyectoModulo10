package dgtic.core.service.usuario;

import dgtic.core.model.entidades.Usuario;
import dgtic.core.repository.repositorio.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class UsuarioServiceImpl implements UsuarioService{

    @Autowired
    UsuarioRepository usuarioRepository;

    @Override
    @Transactional(readOnly = true)
    public Page<Usuario> buscarUsuario(Pageable pageable) {
        return usuarioRepository.findAll(pageable);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Usuario> usuarios() {
        return usuarioRepository.findAll();
    }

    @Override
    @Transactional
    public void guardar(Usuario usuario) {
        usuarioRepository.save(usuario);
    }

    @Override
    @Transactional
    public void borrar(Integer id) {
        usuarioRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Usuario busacarUsuarioId(Integer id) {
        Optional<Usuario> us =usuarioRepository.findById(id);
        return us.orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Usuario> buscarUsuario(Integer id) {
        return usuarioRepository.findAllById(Collections.singleton(id));
    }
}
