package dgtic.core.service.comentariotarea;

public interface ComentarioTareaService {
}
