package dgtic.core.service.tarea;

import dgtic.core.model.entidades.Tarea;
import dgtic.core.model.entidades.Usuario;
import dgtic.core.repository.repositorio.TareaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class TareaServiceImpl implements TareaService {

    @Autowired
    TareaRepository tareaRepository;

    @Override
    public Page<Tarea> buscarTarea(Pageable pageable) {
        return tareaRepository.findAll(pageable);
    }

    @Override
    public List<Tarea> buscarTarea() {
        return tareaRepository.findAll();
    }

    @Override
    public void guardar(Tarea tarea) {
        tareaRepository.save(tarea);
    }

    @Override
    public void borrar(Integer id) {
        tareaRepository.deleteById(id);
    }

    @Override
    public Tarea buscartTareaId(Integer id) {
        Optional<Tarea> ta =tareaRepository.findById(id);
        return ta.orElse(null);
    }

    @Override
    public List<Tarea> buscarTarea(Integer id) {
        return tareaRepository.findAllById(Collections.singleton(id));
    }
}
