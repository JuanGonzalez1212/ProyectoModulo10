package dgtic.core.controller.tarea;

import dgtic.core.model.entidades.EstadoTarea;
import dgtic.core.model.entidades.Tarea;
import dgtic.core.model.entidades.Usuario;
import dgtic.core.service.estadotarea.EstadoTareaService;
import dgtic.core.service.tarea.TareaService;
import dgtic.core.service.usuario.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/tarea")
public class TareaController {

    @Autowired
    private TareaService tareaService;

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private EstadoTareaService estadoTareaService;


    // Guardar una nueva tarea
    @PostMapping
    public ResponseEntity<?> salvarTarea(@Valid @RequestBody Tarea tarea) {
        try {
            tareaService.guardar(tarea);
            return ResponseEntity.status(HttpStatus.CREATED).body(tarea);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error al guardar la tarea: " + e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<?> listaTareas() {
        List<Tarea> tareas = tareaService.buscarTarea(); // Obtener todas las tareas
        return ResponseEntity.ok(tareas); // Devolver la lista como respuesta
    }


    // Obtener una tarea por ID
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerTareaPorId(@PathVariable Integer id) {
        Tarea tarea = tareaService.buscartTareaId(id);
        if (tarea != null) {
            return ResponseEntity.ok(tarea);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Tarea no encontrada con ID: " + id);
    }

    // Eliminar una tarea por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarTarea(@PathVariable Integer id) {
        Tarea tarea = tareaService.buscartTareaId(id);
        if (tarea != null) {
            tareaService.borrar(id);
            return ResponseEntity.ok("Tarea eliminada con éxito");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Tarea no encontrada con ID: " + id);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> modificarTarea(@PathVariable("id") Integer id,
                                            @Valid @RequestBody Tarea tarea,
                                            BindingResult result) {
        if (result.hasErrors()) {
            Map<String, String> errores = new HashMap<>();
            result.getFieldErrors().forEach(error ->
                    errores.put(error.getField(), error.getDefaultMessage())
            );
            return ResponseEntity.badRequest().body(errores);
        }
        Tarea tareaExistente = tareaService.buscartTareaId(id);
        if (tareaExistente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Tarea no encontrada con ID: " + id);
        }
        tarea.setIdTarea(id);
        tareaService.guardar(tarea);
        return ResponseEntity.ok(tarea);
    }

}
