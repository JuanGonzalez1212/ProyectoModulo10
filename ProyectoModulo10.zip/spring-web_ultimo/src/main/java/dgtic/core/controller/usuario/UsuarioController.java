package dgtic.core.controller.usuario;

import dgtic.core.converter.MayusculasConverter;
import dgtic.core.model.entidades.Usuario;
import dgtic.core.service.usuario.UsuarioService;
import dgtic.core.validation.TipoValidacion;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "api/usuario")
public class UsuarioController {
    @Autowired
    TipoValidacion tipoValidacion;

    @Autowired
    UsuarioService usuarioService;

    @PostMapping
    public ResponseEntity<?> salvarUsuario(@Valid @RequestBody Usuario usuario, BindingResult result) {
        if (result.hasErrors()) {
            Map<String, String> errores = new HashMap<>();
            result.getFieldErrors().forEach(error ->
                    errores.put(error.getField(), error.getDefaultMessage()));
            return ResponseEntity.badRequest().body(errores);
        }
        usuarioService.guardar(usuario);
        return ResponseEntity.status(HttpStatus.CREATED).body(usuario);
    }

    @GetMapping
    public ResponseEntity<List<Usuario>> listaUsuario() {
        List<Usuario> usuarios = usuarioService.usuarios();
        return ResponseEntity.ok(usuarios);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable("id") Integer id) {
        Usuario usuario = usuarioService.busacarUsuarioId(id);
        if (usuario == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuario no encontrado");
        }
        usuarioService.borrar(id);
        return ResponseEntity.ok().body("Usuario eliminado con éxito");
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> modificarUsuario(@PathVariable("id") Integer id, @Valid @RequestBody Usuario usuario, BindingResult result) {
        if (result.hasErrors()) {
            Map<String, String> errores = new HashMap<>();
            result.getFieldErrors().forEach(error ->
                    errores.put(error.getField(), error.getDefaultMessage()));
            return ResponseEntity.badRequest().body(errores);
        }
        Usuario usuarioExistente = usuarioService.busacarUsuarioId(id);
        if (usuarioExistente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuario no encontrado");
        }
        usuario.setId(id); // Aseguramos que el ID no cambie
        usuarioService.guardar(usuario);
        return ResponseEntity.ok(usuario);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarUsuarioId(@PathVariable("id") Integer id) {
        Usuario usuario = usuarioService.busacarUsuarioId(id);
        if (usuario == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuario no encontrado");
        }
        return ResponseEntity.ok(usuario);
    }

    @InitBinder("usuario")
    public void nombreUsuario(WebDataBinder binder) {
        binder.registerCustomEditor(String.class, "nombre", new MayusculasConverter());
    }
}
