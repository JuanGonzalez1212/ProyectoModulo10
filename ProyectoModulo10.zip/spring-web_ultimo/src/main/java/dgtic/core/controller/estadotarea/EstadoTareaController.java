package dgtic.core.controller.estadotarea;

import dgtic.core.model.entidades.EstadoTarea;
import dgtic.core.service.estadotarea.EstadoTareaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/estadotarea")
public class EstadoTareaController {

    @Autowired
    private EstadoTareaService estadoTareaService;

    @PostMapping
    public ResponseEntity<?> salvarEstado(@RequestBody EstadoTarea estadoTarea) {
        Map<String, Object> response = new HashMap<>();
        if (estadoTarea.getNombre() == null || estadoTarea.getNombre().isBlank()) {
            response.put("mensaje", "Error: el nombre del estado no debe estar vacío.");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
        estadoTareaService.guardar(estadoTarea);
        response.put("mensaje", "El estado se guardó correctamente.");
        response.put("estadoTarea", estadoTarea);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<EstadoTarea>> listarEstados() {
        // Obtiene todos los estados de tarea como una lista
        List<EstadoTarea> estados = estadoTareaService.estados();
        // Devuelve la lista con un código de estado HTTP 200
        return new ResponseEntity<>(estados, HttpStatus.OK);
    }


    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerEstado(@PathVariable Integer id) {
        EstadoTarea estadoTarea = estadoTareaService.buscarEstadoTareaId(id);
        if (estadoTarea == null) {
            return new ResponseEntity<>("El estado no fue encontrado.", HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(estadoTarea, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarEstadoTarea(@PathVariable Integer id) {
        EstadoTarea estado = estadoTareaService.buscarEstadoTareaId(id);
        if (estado == null) {
            return new ResponseEntity<>("Estado no encontrado.", HttpStatus.NOT_FOUND);
        }
        estadoTareaService.borrar(id);
        return new ResponseEntity<>("Estado eliminado correctamente.", HttpStatus.OK);
    }


    @PutMapping("{id}")
    public ResponseEntity<?> modificarEstado(@PathVariable Integer id, @RequestBody EstadoTarea estadoTarea) {
        Map<String, Object> response = new HashMap<>();
        EstadoTarea estadoExistente = estadoTareaService.buscarEstadoTareaId(id);
        if (estadoExistente == null) {
            response.put("mensaje", "El estado no fue encontrado.");
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }

        if (estadoTarea.getNombre() == null || estadoTarea.getNombre().isBlank()) {
            response.put("mensaje", "Error: el nombre del estado no debe estar vacío.");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }

        estadoExistente.setNombre(estadoTarea.getNombre());
        estadoTareaService.guardar(estadoExistente);

        response.put("mensaje", "El estado se actualizó correctamente.");
        response.put("estadoTarea", estadoExistente);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
