package dgtic.core.controller.rol;

import dgtic.core.converter.MayusculasConverter;
import dgtic.core.model.entidades.Rol;
import dgtic.core.service.rol.RolService;
import dgtic.core.validation.TipoValidacion;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "api/rol")
public class RolController {
    @Autowired
    TipoValidacion tipoValidacion;

    @Autowired
    RolService rolService;

    @PostMapping
    public ResponseEntity<?> salvarRol(@Valid @RequestBody Rol rol, BindingResult result) {
        if (result.hasErrors()) {
            Map<String, String> errores = new HashMap<>();
            result.getFieldErrors().forEach(error ->
                    errores.put(error.getField(), error.getDefaultMessage()));
            return ResponseEntity.badRequest().body(errores);
        }
        rolService.guardar(rol);
        return ResponseEntity.status(HttpStatus.CREATED).body(rol);
    }

    @GetMapping
    public ResponseEntity<List<Rol>> listaRol() {
        List<Rol> roles = rolService.buscarRol();
        return ResponseEntity.ok(roles);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable("id") Integer id) {
        Rol rol = rolService.buscarRolId(id);
        if (rol == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Rol no encontrado");
        }
        rolService.borrar(id);
        return ResponseEntity.ok().body("Rol eliminado con éxito");
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> modificarRol(@PathVariable("id") Integer id, @Valid @RequestBody Rol rol, BindingResult result) {
        if (result.hasErrors()) {
            Map<String, String> errores = new HashMap<>();
            result.getFieldErrors().forEach(error ->
                    errores.put(error.getField(), error.getDefaultMessage()));
            return ResponseEntity.badRequest().body(errores);
        }
        Rol rolExistente = rolService.buscarRolId(id);
        if (rolExistente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Rol no encontrado");
        }
        rol.setId(id); // Aseguramos que el ID no cambie
        rolService.guardar(rol);
        return ResponseEntity.ok(rol);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarRol(@PathVariable("id") Integer id) {
        Rol rol = rolService.buscarRolId(id);
        if (rol == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Rol no encontrado");
        }
        return ResponseEntity.ok(rol);
    }

    @InitBinder("rol")
    public void nombreRol(WebDataBinder binder) {
        binder.registerCustomEditor(String.class, "nombre", new MayusculasConverter());
    }
}
