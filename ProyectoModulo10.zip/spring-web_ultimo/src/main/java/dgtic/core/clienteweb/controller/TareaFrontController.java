package dgtic.core.clienteweb.controller;

import dgtic.core.clienteweb.service.TareaWebClientService;
import dgtic.core.model.entidades.EstadoTarea;
import dgtic.core.model.entidades.Tarea;
import dgtic.core.model.entidades.Usuario;
import dgtic.core.service.estadotarea.EstadoTareaService;
import dgtic.core.service.usuario.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.validation.Valid;
import java.util.List;

@Controller
@RequestMapping("/tarea")
public class TareaFrontController {

    @Autowired
    private TareaWebClientService tareaService;

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private EstadoTareaService estadoTareaService;

    // Mostrar el formulario para dar de alta una tarea
    @GetMapping("/alta-tarea")
    public String altaTarea(Model model) {
        Tarea tarea = new Tarea();
        List<Usuario> usuarios = usuarioService.usuarios();  // Cargar los usuarios disponibles
        List<EstadoTarea> estados = estadoTareaService.estados();  // Cargar los estados disponibles

        model.addAttribute("tarea", tarea);
        model.addAttribute("selectUsuario", usuarios);  // Pasar la lista de usuarios al modelo
        model.addAttribute("selectEstadoTarea", estados);  // Pasar la lista de estados al modelo
        model.addAttribute("contenido", "Alta de una Tarea");

        return "tarea/alta-tarea";  // Nombre de la plantilla HTML
    }

    // Procesar el formulario para guardar la nueva tarea
    @PostMapping("/salvar-tarea")
    public String salvarTarea(@Valid @ModelAttribute("tarea") Tarea tarea,
                              BindingResult result,
                              Model model,
                              RedirectAttributes flash) {
        // Verificar si hay errores en el formulario
        if (result.hasErrors()) {
            List<Usuario> usuarios = usuarioService.usuarios();  // Recargar la lista de usuarios en caso de error
            List<EstadoTarea> estados = estadoTareaService.estados();  // Recargar la lista de estados en caso de error
            model.addAttribute("selectUsuario", usuarios);
            model.addAttribute("selectEstadoTarea", estados);
            model.addAttribute("contenido", "Error en el formulario de tarea");

            return "tarea/alta-tarea";
        }

        tareaService.createTarea(tarea);  // Guardar la tarea a través del WebClient
        flash.addFlashAttribute("success", "Tarea guardada exitosamente");

        return "redirect:/tarea/lista-tarea";  // Redirigir a la lista de tareas
    }

    // Listar todas las tareas sin paginación
    @GetMapping("/lista-tarea")
    public String listaTareas(Model model) {
        List<Tarea> tareas = tareaService.getAll();  // Obtener todas las tareas desde el WebClient
        model.addAttribute("tareas", tareas);
        model.addAttribute("contenido", "Lista de Tareas");

        return "tarea/lista-tarea";  // Nombre de la plantilla para listar tareas
    }

    @GetMapping("/modificar-tarea/{id}")
    public String editarTarea(@PathVariable("id") Integer id, Model model) {
        Tarea tarea = tareaService.getTareaById(id);  // Llama al servicio para obtener la tarea
        if (tarea == null) {
            // Si no se encuentra la tarea, redirige a la lista de tareas con un mensaje de error
            model.addAttribute("error", "Tarea no encontrada");
            return "redirect:/tarea/lista-tarea";
        }
        List<Usuario> usuarios = usuarioService.usuarios();  // Cargar los usuarios disponibles
        List<EstadoTarea> estados = estadoTareaService.estados();  // Cargar los estados disponibles

        model.addAttribute("tarea", tarea);
        model.addAttribute("selectUsuario", usuarios);  // Pasar la lista de usuarios al modelo
        model.addAttribute("selectEstadoTarea", estados);  // Pasar la lista de estados al modelo
        model.addAttribute("contenido", "Editar Tarea");

        return "tarea/lista-tarea";  // Nombre del archivo de plantilla
    }


    // Eliminar una tarea
    @GetMapping("/eliminar-tarea/{id}")
    public String eliminarTarea(@PathVariable("id") Integer id, RedirectAttributes flash) {
        String response = tareaService.deleteTarea(id);  // Eliminar la tarea a través del WebClient
        flash.addFlashAttribute("success", "Tarea eliminada exitosamente");

        return "redirect:/tarea/lista-tarea";  // Redirigir a la lista de tareas
    }
}
