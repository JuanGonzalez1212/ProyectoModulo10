package dgtic.core.clienteweb.service;

import dgtic.core.model.entidades.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class UsuarioWebClientService {
    @Autowired
    private WebClient webClient;

    public List<Usuario> getAll() {
        Mono<List<Usuario>> usuariosMono = webClient.get()
                .uri("/api/usuario")  // Ruta para obtener todos los usuarios
                .retrieve()
                .bodyToFlux(Usuario.class)  // Se deserializa la respuesta como un flujo de usuarios
                .collectList();             // Recoge todos los elementos en una lista

        return usuariosMono.block();  // Espera a que se obtenga la lista
    }

    public Usuario getUsuarioById(Integer id) {
        Mono<Usuario> usuarioMono = webClient.get()
                .uri("/api/usuario/{id}", id)  // Ruta para obtener un usuario por ID
                .retrieve()
                .bodyToMono(Usuario.class);    // Se deserializa la respuesta como un único usuario
        return usuarioMono.block();
    }

    public Usuario createUsuario(Usuario usuario) {
        return webClient.post()
                .uri("/api/usuario")          // Ruta para crear un usuario
                .bodyValue(usuario)           // Enviar el cuerpo de la petición
                .retrieve()
                .bodyToMono(Usuario.class)    // Se deserializa la respuesta como un único usuario
                .block();
    }

    public Usuario updateUsuario(Integer id, Usuario usuario) {
        return webClient.put()
                .uri("/api/usuario/{id}", id) // Ruta para actualizar un usuario por ID
                .bodyValue(usuario)           // Enviar el cuerpo de la petición
                .retrieve()
                .bodyToMono(Usuario.class)    // Se deserializa la respuesta como un único usuario
                .block();
    }

    public String deleteUsuario(Integer id) {
        return webClient.delete()
                .uri("/api/usuario/{id}", id) // Ruta para eliminar un usuario por ID
                .retrieve()
                .bodyToMono(String.class)     // Se espera una respuesta tipo String como confirmación
                .block();
    }
}
