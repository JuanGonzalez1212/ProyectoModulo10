package dgtic.core.clienteweb.service;

import dgtic.core.model.entidades.Tarea;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class TareaWebClientService {
    @Autowired
    private WebClient webClient;

    // Obtener todas las tareas
    public List<Tarea> getAll() {
        Mono<List<Tarea>> tareasMono = webClient.get()
                .uri("/api/tarea")  // Ruta para obtener todas las tareas
                .retrieve()
                .bodyToFlux(Tarea.class)   // Se deserializa la respuesta como un flujo de tareas
                .collectList();            // Recoge todos los elementos en una lista

        return tareasMono.block();  // Espera a que se obtenga la lista
    }

    // Obtener una tarea por su ID
    public Tarea getTareaById(Integer id) {
        Mono<Tarea> tareaMono = webClient.get()
                .uri("/api/tarea/{id}", id)  // Ruta para obtener una tarea por ID
                .retrieve()
                .bodyToMono(Tarea.class);    // Se deserializa la respuesta como una única tarea
        return tareaMono.block();
    }

    // Crear una nueva tarea
    public Tarea createTarea(Tarea tarea) {
        return webClient.post()
                .uri("/api/tarea")           // Ruta para crear una nueva tarea
                .bodyValue(tarea)            // Enviar el cuerpo de la petición
                .retrieve()
                .bodyToMono(Tarea.class)     // Se deserializa la respuesta como una única tarea
                .block();
    }

    // Actualizar una tarea existente
    public Tarea updateTarea(Integer id, Tarea tarea) {
        return webClient.put()
                .uri("/api/tarea/{id}", id)  // Ruta para actualizar una tarea por ID
                .bodyValue(tarea)            // Enviar el cuerpo de la petición
                .retrieve()
                .bodyToMono(Tarea.class)     // Se deserializa la respuesta como una única tarea
                .block();
    }

    // Eliminar una tarea por su ID
    public String deleteTarea(Integer id) {
        return webClient.delete()
                .uri("/api/tarea/{id}", id)  // Ruta para eliminar una tarea por ID
                .retrieve()
                .bodyToMono(String.class)    // Se espera una respuesta tipo String como confirmación
                .block();
    }
}
