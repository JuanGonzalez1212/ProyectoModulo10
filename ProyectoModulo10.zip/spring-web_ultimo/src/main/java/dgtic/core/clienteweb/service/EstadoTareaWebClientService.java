package dgtic.core.clienteweb.service;

import dgtic.core.model.entidades.EstadoTarea;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class EstadoTareaWebClientService {

    @Autowired
    private WebClient webClient;

    // Obtener todos los estados de tarea
    public List<EstadoTarea> getAllEstados() {
        Mono<List<EstadoTarea>> estadosMono = webClient.get()
                .uri("/api/estadotarea")  // Llama al endpoint para listar todos los estados
                .retrieve()
                .bodyToFlux(EstadoTarea.class)  // Deserializa la respuesta como un flujo de objetos EstadoTarea
                .collectList();                 // Recoge todos los elementos en una lista

        return estadosMono.block(); // Bloquea hasta recibir la lista
    }

    // Obtener un estado de tarea por su ID
    public EstadoTarea getEstadoById(Integer id) {
        Mono<EstadoTarea> estadoMono = webClient.get()
                .uri("/api/estadotarea/{id}", id)  // Llama al endpoint para obtener un estado por ID
                .retrieve()
                .bodyToMono(EstadoTarea.class);   // Deserializa la respuesta en un objeto EstadoTarea

        return estadoMono.block(); // Bloquea hasta recibir el objeto
    }

    // Crear un nuevo estado de tarea
    public EstadoTarea createEstado(EstadoTarea estadoTarea) {
        return webClient.post()
                .uri("/api/estadotarea")    // Llama al endpoint para guardar un estado
                .bodyValue(estadoTarea)            // Envía el objeto EstadoTarea en el cuerpo de la petición
                .retrieve()
                .bodyToMono(EstadoTarea.class)     // Deserializa la respuesta en un objeto EstadoTarea
                .block();                          // Bloquea hasta recibir el objeto guardado
    }

    // Actualizar un estado de tarea por su ID
    public EstadoTarea updateEstado(Integer id, EstadoTarea estadoTarea) {
        return webClient.put()
                .uri("/api/estadotarea/{id}", id)  // Llama al endpoint para modificar un estado
                .bodyValue(estadoTarea)                      // Envía el objeto EstadoTarea actualizado
                .retrieve()
                .bodyToMono(EstadoTarea.class)               // Deserializa la respuesta en un objeto EstadoTarea
                .block();                                    // Bloquea hasta recibir el objeto actualizado
    }

    // Eliminar un estado de tarea por su ID
    public String deleteEstado(Integer id) {
        return webClient.delete()
                .uri("/api/estadotarea/{id}", id)  // Llama al endpoint para eliminar un estado
                .retrieve()
                .bodyToMono(String.class)                   // Deserializa la respuesta como un mensaje String
                .block();                                   // Bloquea hasta recibir el mensaje
    }
}
