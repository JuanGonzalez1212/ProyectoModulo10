package dgtic.core.clienteweb.controller;

import dgtic.core.clienteweb.service.UsuarioWebClientService;
import dgtic.core.converter.MayusculasConverter;
import dgtic.core.model.entidades.Rol;
import dgtic.core.model.entidades.Usuario;
import dgtic.core.service.rol.RolService;
import dgtic.core.validation.TipoValidacion;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping(value = "usuario")
public class UsuarioFrontController {

    @Autowired
    TipoValidacion tipoValidacion;

    @Autowired
    UsuarioWebClientService usuarioService;

    @Autowired
    RolService rolService;

    @GetMapping("alta-usuario")
    public String altaUsuario(Model model) {
        Usuario usuario = new Usuario();
        model.addAttribute("contenido", "Alta de un Usuario");
        model.addAttribute("selectRol", rolService.buscarRol());
        model.addAttribute("usuario", usuario);
        return "usuario/alta-usuario";
    }

    @PostMapping("salvar-usuario")
    public String salvarUsuario(@Valid @ModelAttribute("usuario") Usuario usuario, BindingResult result,
                                Model model, RedirectAttributes flash) {
        if (result.hasErrors()) {
            model.addAttribute("contenido", "Error en los datos del usuario, verifique los campos requeridos.");
            return "usuario/alta-usuario";
        }
        usuarioService.createUsuario(usuario);
        flash.addFlashAttribute("success", "Se almacenó con éxito el usuario.");
        return "redirect:/usuario/lista-usuario";
    }

    @GetMapping("lista-usuario")
    public String listaUsuario(Model model) {
        List<Usuario> usuarios = usuarioService.getAll();  // Obtener la lista de usuarios desde el servicio
        model.addAttribute("usuarios", usuarios);
        model.addAttribute("contenido", "Lista de Usuarios Registrados");
        return "usuario/lista-usuario";  // Retorna la vista lista-usuario
    }

    @GetMapping("eliminar-usuario/{id}")
    public String eliminarUsuario(@PathVariable("id") Integer id, RedirectAttributes flash) {
        usuarioService.deleteUsuario(id);
        flash.addFlashAttribute("success", "Se borró con éxito el usuario.");
        return "redirect:/usuario/lista-usuario";
    }

    @GetMapping("modificar-usuario/{id}")
    public String saltoModificarUsuario(@PathVariable("id") Integer id, Model model) {
        Usuario usuario = usuarioService.getUsuarioById(id);
        model.addAttribute("usuario", usuario);
        model.addAttribute("selectRol", rolService.buscarRol());
        model.addAttribute("contenido", "Modificar los Datos del Usuario");
        return "usuario/alta-usuario";
    }

    @InitBinder("usuario")
    public void nombreUsuario(WebDataBinder binder) {
        binder.registerCustomEditor(String.class, "nombre", new MayusculasConverter());
    }
}
